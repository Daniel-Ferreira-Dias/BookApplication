package com.example.bookapplicationv1.fragments

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.RelativeLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.bookapplicationv1.R
import com.example.bookapplicationv1.User
import com.example.bookapplicationv1.databinding.FragmentSearchBinding
import com.example.bookapplicationv1.fragments.adapters.AdapaterPDF
import com.example.bookapplicationv1.fragments.adapters.ModelPDF
import com.example.bookapplicationv1.fragments.adapters.UserAdapter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.fragment_profile.*
import kotlinx.android.synthetic.main.fragment_search.*
import kotlinx.android.synthetic.main.row_books.*
import java.lang.Exception


class SearchFragment : Fragment {

    private lateinit var bookRecyclerView: RecyclerView
    private lateinit var pdfArrayList: ArrayList<ModelPDF>
    private lateinit var adapaterPDF : AdapaterPDF

    private val mAuth = FirebaseAuth.getInstance()
    private val user:FirebaseUser? = mAuth.currentUser
    private val uid = user?.uid.toString()



    constructor()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_search, container, false)



        pdfArrayList = ArrayList()
        adapaterPDF = AdapaterPDF(requireContext(), pdfArrayList)
        bookRecyclerView = view.findViewById(R.id.booksList)
        bookRecyclerView.layoutManager=LinearLayoutManager(requireContext())
        bookRecyclerView.adapter=adapaterPDF

        loadAllBooks()


        return view
    }

    override fun onResume() {
        super.onResume()

        pdfArrayList = ArrayList()
        adapaterPDF = AdapaterPDF(requireContext(), pdfArrayList)
        bookRecyclerView = requireView().findViewById(R.id.booksList)
        bookRecyclerView.layoutManager=LinearLayoutManager(requireContext())
        bookRecyclerView.adapter=adapaterPDF


        loadAllBooks()

    }

    private fun loadAllBooks() {
        val ref = FirebaseDatabase.getInstance().getReference("Livros")
        ref.addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                pdfArrayList.clear()
                for (ds in snapshot.children){
                    val model = ds.getValue(ModelPDF::class.java)
                    pdfArrayList.add(model!!)
                }
                //setup adapter
                booksList.adapter = adapaterPDF
            }
            override fun onCancelled(error: DatabaseError) {
            }
        })
    }




}