package com.example.bookapplicationv1.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.test.services.events.TimeStamp
import com.bumptech.glide.Glide
import com.example.bookapplicationv1.LoginActivity
import com.example.bookapplicationv1.R
import com.example.bookapplicationv1.databinding.ActivityFragmentManagerBinding
import com.example.bookapplicationv1.fragments.adapters.AdapaterPDF
import com.example.bookapplicationv1.fragments.adapters.DialogChangePasswordFragment
import com.example.bookapplicationv1.fragments.adapters.ModelPDF
import com.example.bookapplicationv1.fragments.adapters.MyApplication
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*
import kotlinx.android.synthetic.*
import kotlinx.android.synthetic.main.fragment_profile.*
import kotlinx.android.synthetic.main.fragment_search.*
import org.w3c.dom.Text
import java.lang.Exception
import java.security.Timestamp
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.ZoneId
import java.util.*


class ProfileFragment : Fragment() {

    // firebase auth
    private val mAuth = FirebaseAuth.getInstance()
    private val user: FirebaseUser? = mAuth.currentUser

    // Users information
    private val uid = user?.uid.toString()

    //global
    lateinit var profileFragment: TextView
    lateinit var emailText: TextView
    private lateinit var userProfileName: TextView
    lateinit var userTimestamp: TextView
    lateinit var editSettings: TextView

    //pdfviewer
    private lateinit var bookRecyclerView: RecyclerView
    private lateinit var pdfArrayList: ArrayList<ModelPDF>
    private lateinit var adapaterPDF: AdapaterPDF

    // database
    private lateinit var databaseReference: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_profile, container, false)
        profileFragment = view.findViewById(R.id.userProfileName)
        emailText = view.findViewById(R.id.emailText)
        userProfileName = view.findViewById(R.id.userProfileName)

        userTimestamp = view.findViewById(R.id.userTimestamp)
        editSettings = view.findViewById(R.id.editSettings)

        //pdv viewer
        pdfArrayList = ArrayList()
        adapaterPDF = AdapaterPDF(requireContext(), pdfArrayList)
        bookRecyclerView = view.findViewById(R.id.profileCollection)
        bookRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        bookRecyclerView.adapter = adapaterPDF

        // load data
        loadUserInfo()

        //load books
        loadAllBooks()

        editSettings.setOnClickListener {
            var dialog = DialogChangePasswordFragment()
            dialog.show(childFragmentManager, "customDialog")
        }

        return view
    }

    override fun onResume() {
        super.onResume()

        //pdv viewer
        pdfArrayList = ArrayList()
        adapaterPDF = AdapaterPDF(requireContext(), pdfArrayList)
        bookRecyclerView = requireView().findViewById(R.id.profileCollection)
        bookRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        bookRecyclerView.adapter = adapaterPDF

        //load books
        loadAllBooks()
    }

    private fun loadAllBooks() {
        val ref = FirebaseDatabase.getInstance().getReference("Livros")
        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                pdfArrayList.clear()
                for (ds in snapshot.children) {
                    val model = ds.getValue(ModelPDF::class.java)
                    if (model!!.uid == mAuth.uid) {
                        pdfArrayList.add(model!!)
                    }

                }
                //setup adapter
                profileCollection.adapter = adapaterPDF
            }

            override fun onCancelled(error: DatabaseError) {
            }
        })
    }

    private fun loadUserInfo() {
        // check if user is verified
        databaseReference = FirebaseDatabase.getInstance().getReference("Users")
        databaseReference.child(mAuth.uid!!)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val email = user?.email
                    val name = "${snapshot.child("fullName").value}"
                    val profileImage = "${snapshot.child("userProfilePic").value}"
                    val timestamp = "${snapshot.child("userTimestamp").value}"
                    val uid = "${snapshot.child("userUID").value}"
                    val userType = "${snapshot.child("userType").value}"

                    //format data
                    val date = MyApplication.formatTimeStamp(timestamp.toLong())

                    if (user!!.isEmailVerified) {
                        accountStatus.text = "Verified"
                    } else {
                        accountStatus.text = "Not Verified"
                    }

                    //convert timestamp to proper date
                    //set data
                    userTimestamp.text = date
                    accountType.text = userType
                    emailText.text = email
                    userProfileName.text = name
                    //set image
                    try {
                        Glide.with(profileFragment).load(profileImage)
                            .placeholder(R.drawable.usericon).into(profilePic)
                    } catch (e: Exception) {
                    }
                }

                override fun onCancelled(error: DatabaseError) {

                }
            })
    }
}