package com.example.bookapplicationv1.fragments.adapters

object Constants {
    const val MAX_BYTES_PDF : Long = 50000000
}