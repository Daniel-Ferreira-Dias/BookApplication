package com.example.bookapplicationv1.fragments.adapters

class ModelPDF {
    var uid:String = ""
    var titulo:String = ""
    var descricao:String = ""
    var categoria:String = ""
    var livroEncriptacao:String = ""
    var url:String = ""
    var timestamp:Long = 0
    var id:String = ""


    constructor()

    constructor(
        uid: String,
        titulo: String,
        descricao: String,
        categoria: String,
        livroEncriptacao: String,
        url: String,
        timestamp: Long,
        id: String,
    ) {
        this.uid = uid
        this.titulo = titulo
        this.descricao = descricao
        this.categoria = categoria
        this.livroEncriptacao = livroEncriptacao
        this.url = url
        this.timestamp = timestamp
        this.id = id
    }


}